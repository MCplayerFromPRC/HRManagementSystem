create procedure getNameAndPassById(tp_id in NUMBER,tp_name out VARCHAR2,tp_pass out varchar2)
  as
  begin 
    select S_NAME,S_PASS into tp_name,tp_pass from T_STUDENT where S_ID=tp_id;
  end;
/

