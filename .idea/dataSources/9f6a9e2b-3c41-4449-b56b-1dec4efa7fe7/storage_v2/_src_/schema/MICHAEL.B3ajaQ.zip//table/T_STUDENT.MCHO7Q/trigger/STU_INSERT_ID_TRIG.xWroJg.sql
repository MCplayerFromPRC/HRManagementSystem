create trigger STU_INSERT_ID_TRIG
  before insert
  on T_STUDENT
  for each row
  declare
    autoid number;
    begin
    select SEQ_STUDENT.nextval into autoid from dual;
    :NEW.S_ID:=autoid;
  end;
/

