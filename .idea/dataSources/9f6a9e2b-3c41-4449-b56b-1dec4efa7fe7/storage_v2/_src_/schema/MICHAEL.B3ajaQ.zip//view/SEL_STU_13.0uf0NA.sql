create view SEL_STU_13 as
  select "S_ID","S_NAME","S_PASS","S_SEX","S_AGE" from T_STUDENT where s_id between 1 and 3
/

