create procedure studentaddage
  as
  cursor c_stu is select S_NAME,S_PASS,S_SEX,S_AGE from T_STUDENT;
  c_name t_student.S_NAME%type;
  c_pass t_student.S_PASS%type;
  c_sex t_student.S_SEX%type;
  c_age t_student.S_AGE%type;
begin
  open c_stu;
  loop
    fetch c_stu into c_name,c_pass,c_sex,c_age;
    exit when c_stu%notfound;
    if c_sex='男' then update T_STUDENT set S_AGE=c_age+1 where S_NAME=c_name;
      end if ;
  end loop;
  close c_stu;
  commit ;
end;
/

