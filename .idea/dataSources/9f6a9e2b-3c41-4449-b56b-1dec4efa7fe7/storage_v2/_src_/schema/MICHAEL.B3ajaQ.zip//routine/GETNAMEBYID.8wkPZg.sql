create function getNameById(ts_id in number)
  return varchar2
  as
  ts_name t_student.s_name%type;
  begin
    select s_name into ts_name from T_STUDENT where S_ID=ts_id;
    return ts_name;
  end;
/

